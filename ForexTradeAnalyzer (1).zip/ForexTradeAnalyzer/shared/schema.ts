import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // "demo", "live", "manual"
  accountNumber: text("account_number"),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0"),
  isActive: boolean("is_active").default(true),
});

export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => accounts.id),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(), // "buy", "sell"
  lotSize: decimal("lot_size", { precision: 10, scale: 5 }).notNull(),
  entryPrice: decimal("entry_price", { precision: 10, scale: 5 }).notNull(),
  exitPrice: decimal("exit_price", { precision: 10, scale: 5 }),
  stopLoss: decimal("stop_loss", { precision: 10, scale: 5 }),
  takeProfit: decimal("take_profit", { precision: 10, scale: 5 }),
  openTime: timestamp("open_time").notNull(),
  closeTime: timestamp("close_time"),
  pips: decimal("pips", { precision: 10, scale: 2 }),
  profitLoss: decimal("profit_loss", { precision: 10, scale: 2 }),
  commission: decimal("commission", { precision: 10, scale: 2 }).default("0"),
  swap: decimal("swap", { precision: 10, scale: 2 }).default("0"),
  comment: text("comment"),
  imageUrl: text("image_url"),
  imageTags: text("image_tags").array(),
  aiAnalysis: text("ai_analysis"),
  tags: text("tags").array(),
  tradeId: text("trade_id"), // External trade ID from broker
});

export const csvImports = pgTable("csv_imports", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  accountId: integer("account_id").references(() => accounts.id),
  status: text("status").notNull(), // "pending", "processing", "completed", "failed"
  totalRows: integer("total_rows"),
  successRows: integer("success_rows"),
  errorRows: integer("error_rows"),
  errors: text("errors").array(),
  importTime: timestamp("import_time").defaultNow(),
});

export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  pips: true,
  profitLoss: true,
}).extend({
  lotSize: z.coerce.number().positive(),
  entryPrice: z.coerce.number().positive(),
  exitPrice: z.coerce.number().positive().optional(),
  stopLoss: z.coerce.number().positive().optional(),
  takeProfit: z.coerce.number().positive().optional(),
});

export const insertCsvImportSchema = createInsertSchema(csvImports).omit({
  id: true,
  importTime: true,
});

export type Account = typeof accounts.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type CsvImport = typeof csvImports.$inferSelect;
export type InsertCsvImport = z.infer<typeof insertCsvImportSchema>;
