import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

interface StatsCardsProps {
  accountId?: string;
}

export default function StatsCards({ accountId }: StatsCardsProps) {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/trades/stats", accountId],
    queryFn: () => fetch(`/api/trades/stats${accountId ? `?accountId=${accountId}` : ""}`).then(res => res.json()),
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-20 bg-slate-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Total P&L</p>
              <p className={`text-2xl font-bold mt-1 ${
                stats?.totalPnL >= 0 ? "text-profit" : "text-loss"
              }`}>
                {formatCurrency(stats?.totalPnL || 0)}
              </p>
            </div>
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
              stats?.totalPnL >= 0 ? "bg-green-100" : "bg-red-100"
            }`}>
              <i className={`fas fa-dollar-sign text-xl ${
                stats?.totalPnL >= 0 ? "text-profit" : "text-loss"
              }`}></i>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Win Rate</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {formatPercentage(stats?.winRate || 0)}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <i className="fas fa-target text-blue-600 text-xl"></i>
            </div>
          </div>
          <div className="flex items-center mt-4 text-sm">
            <span className="text-slate-500">
              {stats?.winningTrades || 0} wins / {stats?.totalTrades || 0} total
            </span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Profit Factor</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {stats?.profitFactor?.toFixed(2) || "0.00"}
              </p>
            </div>
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
              <i className="fas fa-chart-bar text-indigo-600 text-xl"></i>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Max Drawdown</p>
              <p className="text-2xl font-bold text-loss mt-1">
                -{formatPercentage(stats?.maxDrawdown || 0)}
              </p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <i className="fas fa-exclamation-triangle text-loss text-xl"></i>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
