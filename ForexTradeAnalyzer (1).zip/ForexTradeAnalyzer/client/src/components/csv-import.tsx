import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function CsvImport() {
  const [importStatus, setImportStatus] = useState<{
    status: "idle" | "uploading" | "processing" | "completed" | "error";
    progress: number;
    message: string;
    result?: any;
  }>({
    status: "idle",
    progress: 0,
    message: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const importMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("csvFile", file);
      formData.append("accountId", "1"); // Default account

      setImportStatus({
        status: "uploading",
        progress: 25,
        message: "Uploading CSV file...",
      });

      const response = await apiRequest("POST", "/api/csv-import", formData);
      return response.json();
    },
    onSuccess: (result) => {
      setImportStatus({
        status: "completed",
        progress: 100,
        message: `Import completed successfully`,
        result,
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/trades"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trades/stats"] });
      
      toast({
        title: "Import Successful",
        description: `${result.successRows} trades imported successfully`,
      });
    },
    onError: (error) => {
      setImportStatus({
        status: "error",
        progress: 0,
        message: "Import failed. Please try again.",
      });
      
      toast({
        title: "Import Failed",
        description: "Failed to import CSV file. Please check the format and try again.",
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      if (!file.name.endsWith(".csv")) {
        toast({
          title: "Invalid File Type",
          description: "Please select a CSV file.",
          variant: "destructive",
        });
        return;
      }

      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast({
          title: "File Too Large",
          description: "Please select a CSV file smaller than 10MB.",
          variant: "destructive",
        });
        return;
      }

      importMutation.mutate(file);
    }
  }, [importMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "text/csv": [".csv"],
    },
    multiple: false,
  });

  const resetImport = () => {
    setImportStatus({
      status: "idle",
      progress: 0,
      message: "",
    });
  };

  const downloadTemplate = () => {
    const csvContent = `Symbol,Direction,Lot Size,Entry Price,Exit Price,Stop Loss,Take Profit,Open Time,Close Time,Comment
EURUSD,buy,0.10,1.08459,1.08789,1.08123,1.09123,2024-01-15 10:30:00,2024-01-15 12:45:00,Example trade
XAUUSD,sell,0.05,1945.67,1943.21,1948.50,1942.00,2024-01-15 14:15:00,2024-01-15 16:30:00,Gold scalp`;

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "forex_trades_template.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>CSV Import</CardTitle>
            <p className="text-sm text-slate-600 mt-1">
              Import trades from MT4/MT5, cTrader, or custom CSV files
            </p>
          </div>
          <Button variant="outline" onClick={downloadTemplate}>
            <i className="fas fa-download mr-2"></i>
            Download Template
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload Zone */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-3">
              Select CSV File
            </label>
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                isDragActive
                  ? "border-blue-400 bg-blue-50"
                  : "border-slate-300 hover:border-blue-400"
              } ${importStatus.status === "processing" ? "pointer-events-none opacity-50" : ""}`}
            >
              <input {...getInputProps()} />
              <i className="fas fa-file-csv text-4xl text-slate-400 mb-4"></i>
              {isDragActive ? (
                <p className="text-blue-600 font-medium mb-2">Drop your CSV file here</p>
              ) : (
                <p className="text-slate-600 font-medium mb-2">Drop your CSV file here</p>
              )}
              <p className="text-sm text-slate-500 mb-4">
                Supports MT4/MT5, cTrader, TradingView exports
              </p>
              <Button type="button" disabled={importStatus.status === "processing"}>
                Choose CSV File
              </Button>
            </div>

            {/* Import Progress */}
            {importStatus.status !== "idle" && (
              <div className="mt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-600">
                    {importStatus.message}
                  </span>
                  {importStatus.status === "completed" && (
                    <Badge variant="default">
                      <i className="fas fa-check mr-1"></i>
                      Complete
                    </Badge>
                  )}
                  {importStatus.status === "error" && (
                    <Badge variant="destructive">
                      <i className="fas fa-times mr-1"></i>
                      Error
                    </Badge>
                  )}
                </div>
                
                {importStatus.status !== "error" && (
                  <Progress value={importStatus.progress} className="w-full" />
                )}

                {importStatus.result && (
                  <div className="mt-4 p-4 bg-slate-50 rounded-lg">
                    <h4 className="font-medium text-slate-800 mb-2">Import Summary</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-slate-600">Format Detected:</span>
                        <span className="ml-2 font-medium">
                          {importStatus.result.detectedFormat.toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-600">Total Rows:</span>
                        <span className="ml-2 font-medium">
                          {importStatus.result.totalRows}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-600">Successful:</span>
                        <span className="ml-2 font-medium text-profit">
                          {importStatus.result.successRows}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-600">Errors:</span>
                        <span className="ml-2 font-medium text-loss">
                          {importStatus.result.errorRows}
                        </span>
                      </div>
                    </div>
                    
                    {importStatus.result.errors?.length > 0 && (
                      <div className="mt-3">
                        <details className="cursor-pointer">
                          <summary className="text-sm font-medium text-slate-700">
                            View Errors ({importStatus.result.errors.length})
                          </summary>
                          <div className="mt-2 max-h-32 overflow-y-auto">
                            {importStatus.result.errors.map((error: string, index: number) => (
                              <div key={index} className="text-xs text-red-600 py-1">
                                {error}
                              </div>
                            ))}
                          </div>
                        </details>
                      </div>
                    )}
                  </div>
                )}

                <div className="flex justify-end">
                  <Button variant="outline" onClick={resetImport}>
                    Import Another File
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Format Detection Info */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-3">
              Supported Formats
            </label>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <i className="fas fa-check-circle text-green-600 mr-2"></i>
                  <span className="font-medium text-green-800">MT4/MT5 Format</span>
                </div>
                <div className="space-y-1 text-sm text-green-700">
                  <div>Required columns: Ticket, Symbol, Type, Volume, Open Time</div>
                  <div>Optional: Close Time, Close Price, Profit, Comment</div>
                </div>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <i className="fas fa-check-circle text-blue-600 mr-2"></i>
                  <span className="font-medium text-blue-800">cTrader Format</span>
                </div>
                <div className="space-y-1 text-sm text-blue-700">
                  <div>Required columns: Position ID, Symbol, Side, Volume</div>
                  <div>Optional: Entry Price, Close Price, Open Timestamp</div>
                </div>
              </div>

              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <div className="flex items-center mb-2">
                  <i className="fas fa-check-circle text-purple-600 mr-2"></i>
                  <span className="font-medium text-purple-800">Custom Format</span>
                </div>
                <div className="space-y-1 text-sm text-purple-700">
                  <div>Use our template for best results</div>
                  <div>Auto-detects column mapping</div>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h4 className="text-sm font-medium text-slate-700 mb-2">Import Options</h4>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-slate-600">Skip duplicate trades</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-slate-600">Auto-calculate missing fields</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-slate-600">Include pending orders</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
