import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertTradeSchema } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { z } from "zod";

const CURRENCY_PAIRS = [
  "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD",
  "EURJPY", "GBPJPY", "AUDJPY", "CHFJPY", "CADJPY", "NZDJPY",
  "EURGBP", "EURAUD", "EURCHF", "EURCAD", "EURNZD",
  "GBPAUD", "GBPCHF", "GBPCAD", "GBPNZD",
  "AUDCHF", "AUDCAD", "AUDNZD",
  "CADCHF", "NZDCHF", "NZDCAD",
  "XAUUSD", "XAGUSD"
];

type TradeFormData = z.infer<typeof insertTradeSchema>;

interface TradeFormProps {
  onSuccess?: () => void;
  defaultValues?: Partial<TradeFormData>;
}

export default function TradeForm({ onSuccess, defaultValues }: TradeFormProps) {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<TradeFormData>({
    resolver: zodResolver(insertTradeSchema),
    defaultValues: {
      accountId: 1,
      direction: "buy",
      openTime: new Date(),
      ...defaultValues,
    },
  });

  const tradeMutation = useMutation({
    mutationFn: async (data: TradeFormData & { image?: File }) => {
      const formData = new FormData();
      
      Object.entries(data).forEach(([key, value]) => {
        if (key !== "image" && value !== undefined) {
          formData.append(key, value.toString());
        }
      });

      if (data.image) {
        formData.append("image", data.image);
      }

      return apiRequest("POST", "/api/trades", formData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trades"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trades/stats"] });
      toast({
        title: "Trade Added",
        description: "Trade has been successfully added to your journal.",
      });
      form.reset();
      setSelectedImage(null);
      setImagePreview(null);
      setAiAnalysis(null);
      onSuccess?.();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add trade. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select an image smaller than 5MB.",
          variant: "destructive",
        });
        return;
      }

      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: TradeFormData) => {
    tradeMutation.mutate({
      ...data,
      image: selectedImage || undefined,
    });
  };

  const toggleDirection = () => {
    const currentDirection = form.getValues("direction");
    form.setValue("direction", currentDirection === "buy" ? "sell" : "buy");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Trade</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <FormField
                control={form.control}
                name="symbol"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency Pair</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select pair" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {CURRENCY_PAIRS.map((pair) => (
                          <SelectItem key={pair} value={pair}>
                            {pair}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="direction"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Direction</FormLabel>
                    <div className="flex bg-slate-100 rounded-lg p-1">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className={`flex-1 ${
                          field.value === "buy"
                            ? "bg-profit text-white hover:bg-profit/90"
                            : "text-slate-600 hover:text-slate-800"
                        }`}
                        onClick={() => form.setValue("direction", "buy")}
                      >
                        Buy
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className={`flex-1 ${
                          field.value === "sell"
                            ? "bg-loss text-white hover:bg-loss/90"
                            : "text-slate-600 hover:text-slate-800"
                        }`}
                        onClick={() => form.setValue("direction", "sell")}
                      >
                        Sell
                      </Button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="lotSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Lot Size</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.10"
                        className="font-mono"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="entryPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Entry Price</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.00001"
                        placeholder="1.08459"
                        className="font-mono"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="exitPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Exit Price (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.00001"
                        placeholder="1.08789"
                        className="font-mono"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="stopLoss"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Stop Loss (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.00001"
                        placeholder="1.08123"
                        className="font-mono"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="takeProfit"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Take Profit (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        step="0.00001"
                        placeholder="1.09123"
                        className="font-mono"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="openTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Open Time</FormLabel>
                    <FormControl>
                      <Input
                        type="datetime-local"
                        {...field}
                        value={field.value instanceof Date ? field.value.toISOString().slice(0, 16) : field.value}
                        onChange={(e) => field.onChange(new Date(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <FormField
                control={form.control}
                name="comment"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Comment (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Trade notes, strategy, or observations..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Image Upload */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Trade Screenshot (Optional)
                </label>
                <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
                  {imagePreview ? (
                    <div className="space-y-4">
                      <img
                        src={imagePreview}
                        alt="Trade screenshot preview"
                        className="max-w-full h-48 object-contain mx-auto rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setSelectedImage(null);
                          setImagePreview(null);
                          setAiAnalysis(null);
                        }}
                      >
                        Remove Image
                      </Button>
                    </div>
                  ) : (
                    <>
                      <i className="fas fa-cloud-upload-alt text-3xl text-slate-400 mb-3"></i>
                      <p className="text-slate-600 font-medium">
                        Drag and drop your chart screenshot here
                      </p>
                      <p className="text-sm text-slate-500 mt-1">
                        or click to browse files • PNG, JPG, WebP up to 5MB
                      </p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        className="hidden"
                        id="image-upload"
                      />
                      <label htmlFor="image-upload">
                        <Button type="button" className="mt-3" asChild>
                          <span>Choose File</span>
                        </Button>
                      </label>
                    </>
                  )}
                </div>

                {aiAnalysis && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="flex items-start">
                      <i className="fas fa-robot text-blue-600 mt-1 mr-3"></i>
                      <div>
                        <p className="text-sm font-medium text-blue-800">AI Analysis Complete</p>
                        {aiAnalysis.patterns?.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {aiAnalysis.patterns.map((pattern: string, index: number) => (
                              <span
                                key={index}
                                className="px-2 py-1 bg-blue-200 text-blue-800 text-xs font-medium rounded"
                              >
                                {pattern}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  form.reset();
                  setSelectedImage(null);
                  setImagePreview(null);
                  setAiAnalysis(null);
                }}
              >
                Clear Form
              </Button>
              <Button type="submit" disabled={tradeMutation.isPending}>
                {tradeMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Adding Trade...
                  </>
                ) : (
                  <>
                    <i className="fas fa-plus mr-2"></i>
                    Add Trade
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
