import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

interface TradesTableProps {
  accountId?: string;
  limit?: number;
}

export default function TradesTable({ accountId, limit }: TradesTableProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: trades, isLoading } = useQuery({
    queryKey: ["/api/trades", accountId],
    queryFn: () => fetch(`/api/trades${accountId ? `?accountId=${accountId}` : ""}`).then(res => res.json()),
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Trades</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-16 bg-slate-200 rounded animate-pulse"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const filteredTrades = trades
    ?.filter((trade: any) => 
      trade.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trade.direction.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trade.comment?.toLowerCase().includes(searchQuery.toLowerCase())
    )
    ?.sort((a: any, b: any) => new Date(b.openTime).getTime() - new Date(a.openTime).getTime())
    ?.slice(0, limit) || [];

  const formatCurrency = (value: string | null) => {
    if (!value) return "-";
    const num = parseFloat(value);
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(num);
  };

  const formatPrice = (value: string) => {
    return parseFloat(value).toFixed(5);
  };

  const formatDuration = (openTime: string, closeTime?: string | null) => {
    if (!closeTime) return "Open";
    const open = new Date(openTime);
    const close = new Date(closeTime);
    const diffMs = close.getTime() - open.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 24) {
      const days = Math.floor(diffHours / 24);
      const hours = diffHours % 24;
      return `${days}d ${hours}h`;
    } else if (diffHours > 0) {
      return `${diffHours}h ${diffMinutes}m`;
    } else {
      return `${diffMinutes}m`;
    }
  };

  const getCurrencyIcon = (symbol: string) => {
    const base = symbol.substring(0, 3);
    const colors: { [key: string]: string } = {
      XAU: "bg-yellow-100 text-yellow-600",
      EUR: "bg-blue-100 text-blue-600",
      GBP: "bg-red-100 text-red-600",
      USD: "bg-green-100 text-green-600",
      JPY: "bg-purple-100 text-purple-600",
      CHF: "bg-orange-100 text-orange-600",
      AUD: "bg-teal-100 text-teal-600",
      CAD: "bg-pink-100 text-pink-600",
      NZD: "bg-indigo-100 text-indigo-600",
    };
    
    return colors[base] || "bg-gray-100 text-gray-600";
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Trades</CardTitle>
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Search trades..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64"
            />
            <Button variant="outline" size="sm">
              <i className="fas fa-filter"></i>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Trade ID</TableHead>
                <TableHead>Symbol</TableHead>
                <TableHead>Direction</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Entry</TableHead>
                <TableHead>Exit</TableHead>
                <TableHead>Pips</TableHead>
                <TableHead>P&L</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTrades.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-8 text-slate-500">
                    No trades found
                  </TableCell>
                </TableRow>
              ) : (
                filteredTrades.map((trade: any) => (
                  <TableRow key={trade.id}>
                    <TableCell className="font-mono text-blue-600">
                      #{trade.id}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <div className={`w-6 h-6 rounded mr-2 flex items-center justify-center ${getCurrencyIcon(trade.symbol)}`}>
                          <span className="text-xs font-bold">
                            {trade.symbol.substring(0, 3)}
                          </span>
                        </div>
                        <span className="font-medium">{trade.symbol}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={trade.direction === "buy" ? "default" : "destructive"}>
                        {trade.direction}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono">{trade.lotSize}</TableCell>
                    <TableCell className="font-mono">{formatPrice(trade.entryPrice)}</TableCell>
                    <TableCell className="font-mono">
                      {trade.exitPrice ? formatPrice(trade.exitPrice) : "-"}
                    </TableCell>
                    <TableCell className={`font-mono ${
                      trade.pips 
                        ? parseFloat(trade.pips) >= 0 
                          ? "text-profit" 
                          : "text-loss"
                        : ""
                    }`}>
                      {trade.pips ? `${parseFloat(trade.pips) >= 0 ? "+" : ""}${parseFloat(trade.pips).toFixed(1)}` : "-"}
                    </TableCell>
                    <TableCell className={`font-mono ${
                      trade.profitLoss 
                        ? parseFloat(trade.profitLoss) >= 0 
                          ? "text-profit" 
                          : "text-loss"
                        : ""
                    }`}>
                      {trade.profitLoss ? formatCurrency(trade.profitLoss) : "-"}
                    </TableCell>
                    <TableCell className="text-slate-600">
                      {formatDuration(trade.openTime, trade.closeTime)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" title="View Details">
                          <i className="fas fa-eye text-sm"></i>
                        </Button>
                        {trade.imageUrl && (
                          <Button variant="ghost" size="sm" title="View Chart">
                            <i className="fas fa-image text-sm"></i>
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        
        {!limit && filteredTrades.length > 0 && (
          <div className="mt-6 flex items-center justify-between">
            <div className="text-sm text-slate-600">
              Showing {filteredTrades.length} of {trades?.length || 0} trades
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="default" size="sm">1</Button>
              <Button variant="outline" size="sm">2</Button>
              <Button variant="outline" size="sm">3</Button>
              <Button variant="outline" size="sm">
                Next
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
