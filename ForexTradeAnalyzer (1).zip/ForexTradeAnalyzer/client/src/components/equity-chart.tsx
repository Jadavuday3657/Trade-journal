import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

interface EquityChartProps {
  accountId?: string;
}

export default function EquityChart({ accountId }: EquityChartProps) {
  const [timeframe, setTimeframe] = useState("1M");

  const { data: trades, isLoading } = useQuery({
    queryKey: ["/api/trades", accountId],
    queryFn: () => fetch(`/api/trades${accountId ? `?accountId=${accountId}` : ""}`).then(res => res.json()),
  });

  if (isLoading) {
    return (
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Equity Curve</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-slate-200 rounded-lg animate-pulse"></div>
        </CardContent>
      </Card>
    );
  }

  // Calculate equity curve data
  const equityData = trades
    ?.filter((trade: any) => trade.profitLoss)
    ?.sort((a: any, b: any) => new Date(a.openTime).getTime() - new Date(b.openTime).getTime())
    ?.reduce((acc: any[], trade: any, index: number) => {
      const previousEquity = acc[index - 1]?.equity || 0;
      const currentEquity = previousEquity + parseFloat(trade.profitLoss || "0");
      acc.push({
        date: trade.openTime,
        equity: currentEquity,
        trade: trade,
      });
      return acc;
    }, []) || [];

  const timeframes = [
    { key: "1M", label: "1M" },
    { key: "3M", label: "3M" },
    { key: "6M", label: "6M" },
    { key: "1Y", label: "1Y" },
  ];

  return (
    <Card className="lg:col-span-2">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Equity Curve</CardTitle>
          <div className="flex items-center space-x-2">
            {timeframes.map((tf) => (
              <Button
                key={tf.key}
                variant={timeframe === tf.key ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe(tf.key)}
              >
                {tf.label}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg flex items-center justify-center border border-slate-200">
          <div className="text-center">
            <i className="fas fa-chart-line text-4xl text-slate-400 mb-4"></i>
            <p className="text-slate-600 font-medium">Interactive Equity Curve</p>
            <p className="text-sm text-slate-500 mt-1">
              {equityData.length > 0 
                ? `${equityData.length} trades plotted` 
                : "No closed trades to display"
              }
            </p>
            {equityData.length > 0 && (
              <p className="text-xs text-slate-400 mt-2">
                Latest Equity: ${equityData[equityData.length - 1]?.equity?.toFixed(2) || "0.00"}
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
