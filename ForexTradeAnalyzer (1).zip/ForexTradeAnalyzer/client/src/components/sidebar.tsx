import { Link, useLocation } from "wouter";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useSidebar } from "@/contexts/SidebarContext";

export default function Sidebar() {
  const [location] = useLocation();
  const [selectedAccount, setSelectedAccount] = useState("1");
  const { isCollapsed } = useSidebar();

  const { data: accounts = [] } = useQuery({
    queryKey: ["/api/accounts"],
  });

  const navItems = [
    { path: "/", label: "Dashboard", icon: "fas fa-chart-line" },
    { path: "/add-trade", label: "Add Trade", icon: "fas fa-plus" },
    { path: "/import-csv", label: "Import CSV", icon: "fas fa-upload" },
    { path: "/trade-history", label: "Trade History", icon: "fas fa-history" },
    { path: "/ai-insights", label: "AI Insights", icon: "fas fa-brain" },
    { path: "/export", label: "Export", icon: "fas fa-download" },
  ];

  return (
    <aside className={`${isCollapsed ? 'w-16' : 'w-64'} bg-white border-r border-slate-200 flex flex-col transition-all duration-300 ease-in-out`}>
      <div className={`${isCollapsed ? 'p-4' : 'p-6'} border-b border-slate-200`}>
        {!isCollapsed ? (
          <>
            <h1 className="text-xl font-bold text-slate-800">ForexAI Journal</h1>
            <p className="text-sm text-slate-500 mt-1">Professional Trading Analytics</p>
          </>
        ) : (
          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
            <i className="fas fa-chart-line text-blue-600"></i>
          </div>
        )}
      </div>
      
      {/* Account Selector */}
      {!isCollapsed && (
        <div className="p-4 border-b border-slate-200">
          <label className="block text-xs font-medium text-slate-600 mb-2">Active Account</label>
          <Select value={selectedAccount} onValueChange={setSelectedAccount}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select account" />
            </SelectTrigger>
            <SelectContent>
              {accounts.map((account: any) => (
                <SelectItem key={account.id} value={account.id.toString()}>
                  {account.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link href={item.path} className={`flex items-center ${isCollapsed ? 'justify-center p-3' : 'p-3'} text-sm font-medium rounded-lg transition-colors ${
                location === item.path
                  ? "text-blue-600 bg-blue-50"
                  : "text-slate-600 hover:bg-slate-50"
              }`} title={isCollapsed ? item.label : undefined}>
                <i className={`${item.icon} ${isCollapsed ? 'text-lg' : 'w-5 mr-3'}`}></i>
                {!isCollapsed && item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {/* Sync Status */}
      <div className="p-4 border-t border-slate-200">
        {!isCollapsed ? (
          <>
            <div className="flex items-center text-xs text-slate-500">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              <span>MT5 Sync Active</span>
            </div>
            <div className="text-xs text-slate-400 mt-1">Last sync: 2 minutes ago</div>
          </>
        ) : (
          <div className="flex justify-center">
            <div className="w-2 h-2 bg-green-500 rounded-full" title="MT5 Sync Active"></div>
          </div>
        )}
      </div>
    </aside>
  );
}
