import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import Dashboard from "@/pages/dashboard";
import AddTrade from "@/pages/add-trade";
import ImportCsv from "@/pages/import-csv";
import TradeHistory from "@/pages/trade-history";
import AiInsights from "@/pages/ai-insights";
import Export from "@/pages/export";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/sidebar";
import { SidebarProvider, useSidebar } from "@/contexts/SidebarContext";

function Router() {
  const { toggle, isCollapsed } = useSidebar();

  return (
    <div className="min-h-screen flex bg-slate-50">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        {/* Toggle Button */}
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-3 flex items-center">
          <Button
            variant="outline"
            size="sm"
            onClick={toggle}
            className="hover:bg-slate-100 border-slate-300"
            title={isCollapsed ? "Show Sidebar" : "Hide Sidebar"}
          >
            <i className={`fas ${isCollapsed ? 'fa-bars' : 'fa-times'} text-slate-700`}></i>
          </Button>
          <span className="ml-3 text-sm text-slate-600 font-medium">
            {isCollapsed ? "Sidebar Hidden" : "Sidebar Visible"}
          </span>
        </div>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/add-trade" component={AddTrade} />
          <Route path="/import-csv" component={ImportCsv} />
          <Route path="/trade-history" component={TradeHistory} />
          <Route path="/ai-insights" component={AiInsights} />
          <Route path="/export" component={Export} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider>
          <Toaster />
          <Router />
        </SidebarProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
