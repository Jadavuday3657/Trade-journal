import TradesTable from "@/components/trades-table";

export default function TradeHistory() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Bar */}
      <header className="bg-white border-b border-slate-200 p-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Trade History</h2>
          <p className="text-slate-600 mt-1">
            Complete history of all your trading activity
          </p>
        </div>
      </header>

      <div className="p-6">
        <TradesTable />
      </div>
    </div>
  );
}
