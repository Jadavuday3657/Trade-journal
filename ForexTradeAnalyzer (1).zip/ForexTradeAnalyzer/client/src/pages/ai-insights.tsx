import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

export default function AiInsights() {
  const [selectedAccount, setSelectedAccount] = useState("1");

  const { data: insights, isLoading, refetch } = useQuery({
    queryKey: ["/api/ai-insights", selectedAccount],
    queryFn: () => fetch(`/api/ai-insights?accountId=${selectedAccount}`).then(res => res.json()),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <header className="bg-white border-b border-slate-200 p-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">AI Performance Insights</h2>
            <p className="text-slate-600 mt-1">
              AI-powered analysis of your trading performance
            </p>
          </div>
        </header>
        <div className="p-6">
          <div className="space-y-6">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-32 bg-slate-200 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Bar */}
      <header className="bg-white border-b border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center mr-3">
              <i className="fas fa-robot text-indigo-600 text-lg"></i>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-800">AI Performance Insights</h2>
              <p className="text-slate-600 mt-1">
                Generated from your recent trading activity
              </p>
            </div>
          </div>
          <Button onClick={() => refetch()}>
            <i className="fas fa-sync-alt mr-2"></i>
            Refresh Analysis
          </Button>
        </div>
      </header>

      <div className="p-6 space-y-6">
        {/* Key Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {insights?.insights?.slice(0, 2).map((insight: string, index: number) => (
            <Card key={index} className="border-green-200 bg-green-50">
              <CardContent className="p-5">
                <div className="flex items-start">
                  <i className="fas fa-thumbs-up text-green-600 mt-1 mr-3"></i>
                  <div>
                    <h4 className="font-semibold text-green-800 mb-2">Performance Insight</h4>
                    <p className="text-sm text-green-700">{insight}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Warnings */}
        {insights?.warnings?.length > 0 && (
          <div className="grid grid-cols-1 gap-4">
            {insights.warnings.map((warning: string, index: number) => (
              <Card key={index} className="border-amber-200 bg-amber-50">
                <CardContent className="p-5">
                  <div className="flex items-start">
                    <i className="fas fa-exclamation-triangle text-amber-600 mt-1 mr-3"></i>
                    <div>
                      <h4 className="font-semibold text-amber-800 mb-2">Risk Management Alert</h4>
                      <p className="text-sm text-amber-700">{warning}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Detailed Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>Personalized Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {insights?.recommendations?.map((recommendation: string, index: number) => (
                <div key={index} className="flex items-start p-4 bg-slate-50 rounded-lg">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-4 mt-1">
                    <span className="text-xs font-bold text-blue-600">{index + 1}</span>
                  </div>
                  <div>
                    <h5 className="font-medium text-slate-800">Recommendation {index + 1}</h5>
                    <p className="text-sm text-slate-600 mt-1">{recommendation}</p>
                    <div className="flex items-center mt-2 text-xs text-slate-500">
                      <i className="fas fa-chart-line mr-1"></i>
                      <span>AI-generated insight</span>
                    </div>
                  </div>
                </div>
              ))}
              
              {(!insights?.recommendations || insights.recommendations.length === 0) && (
                <div className="text-center py-8 text-slate-500">
                  <i className="fas fa-brain text-4xl text-slate-300 mb-4"></i>
                  <p>Not enough trading data for detailed recommendations</p>
                  <p className="text-sm mt-1">Add more trades to get personalized insights</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Weekly Goals */}
        {insights?.weeklyGoals && (
          <Card>
            <CardHeader>
              <CardTitle>Weekly Performance Goals</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-slate-600">Win Rate Target</span>
                    <span className="text-sm font-bold text-slate-800">
                      {insights.weeklyGoals.winRateTarget}%
                    </span>
                  </div>
                  <Progress value={65} className="w-full" />
                  <div className="text-xs text-slate-500 mt-1">
                    Current: 65% ({insights.weeklyGoals.winRateTarget - 65}% to go)
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-slate-600">Weekly P&L Target</span>
                    <span className="text-sm font-bold text-slate-800">
                      ${insights.weeklyGoals.pnlTarget}
                    </span>
                  </div>
                  <Progress value={80} className="w-full" />
                  <div className="text-xs text-slate-500 mt-1">
                    Current: ${Math.round(insights.weeklyGoals.pnlTarget * 0.8)} (ahead of pace)
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-slate-600">Max Daily Drawdown</span>
                    <span className="text-sm font-bold text-slate-800">
                      -{insights.weeklyGoals.maxDrawdown}%
                    </span>
                  </div>
                  <Progress value={75} className="w-full" />
                  <div className="text-xs text-slate-500 mt-1">
                    Today: -0.5% (well within limits)
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
