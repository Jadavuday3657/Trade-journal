import { useState } from "react";
import StatsCards from "@/components/stats-cards";
import EquityChart from "@/components/equity-chart";
import TradesTable from "@/components/trades-table";
import TradeForm from "@/components/trade-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

export default function Dashboard() {
  const [selectedAccount, setSelectedAccount] = useState("1");
  const [showTradeForm, setShowTradeForm] = useState(false);

  const { data: trades } = useQuery({
    queryKey: ["/api/trades", selectedAccount],
    queryFn: () => fetch(`/api/trades?accountId=${selectedAccount}`).then(res => res.json()),
  });

  // Calculate performance by pair
  const performanceByPair = trades?.reduce((acc: any, trade: any) => {
    if (!trade.profitLoss) return acc;
    
    if (!acc[trade.symbol]) {
      acc[trade.symbol] = {
        symbol: trade.symbol,
        trades: 0,
        wins: 0,
        totalPnL: 0,
      };
    }
    
    acc[trade.symbol].trades++;
    if (parseFloat(trade.profitLoss) > 0) {
      acc[trade.symbol].wins++;
    }
    acc[trade.symbol].totalPnL += parseFloat(trade.profitLoss);
    
    return acc;
  }, {});

  const topPairs = Object.values(performanceByPair || {})
    .sort((a: any, b: any) => b.totalPnL - a.totalPnL)
    .slice(0, 5);

  const getCurrencyIcon = (symbol: string) => {
    const base = symbol.substring(0, 3);
    const colors: { [key: string]: string } = {
      XAU: "bg-yellow-100 text-yellow-600",
      EUR: "bg-blue-100 text-blue-600",
      GBP: "bg-red-100 text-red-600",
      USD: "bg-green-100 text-green-600",
      JPY: "bg-purple-100 text-purple-600",
    };
    return colors[base] || "bg-gray-100 text-gray-600";
  };

  return (
    <div className="bg-slate-50">
      {/* Page Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Trading Dashboard</h2>
            <p className="text-slate-600 mt-1">
              Real-time performance analytics and trade management
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline">
              <i className="fas fa-sync-alt mr-2"></i>
              Refresh
            </Button>
            <Button onClick={() => setShowTradeForm(true)}>
              <i className="fas fa-plus mr-2"></i>
              Add Trade
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <StatsCards accountId={selectedAccount} />

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <EquityChart accountId={selectedAccount} />

          {/* Performance by Pair */}
          <Card>
            <CardHeader>
              <CardTitle>Performance by Pair</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topPairs.length === 0 ? (
                  <p className="text-slate-500 text-center py-8">
                    No trading data available
                  </p>
                ) : (
                  topPairs.map((pair: any) => (
                    <div key={pair.symbol} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${getCurrencyIcon(pair.symbol)}`}>
                          <span className="text-xs font-bold">
                            {pair.symbol.substring(0, 3)}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-slate-800">{pair.symbol}</p>
                          <p className="text-xs text-slate-500">{pair.trades} trades</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${
                          pair.totalPnL >= 0 ? "text-profit" : "text-loss"
                        }`}>
                          {pair.totalPnL >= 0 ? "+" : ""}
                          ${pair.totalPnL.toFixed(0)}
                        </p>
                        <p className="text-xs text-slate-500">
                          {((pair.wins / pair.trades) * 100).toFixed(0)}% WR
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trade Entry Form */}
        {showTradeForm && (
          <TradeForm onSuccess={() => setShowTradeForm(false)} />
        )}

        {/* Recent Trades Table */}
        <TradesTable accountId={selectedAccount} limit={10} />
      </div>
    </div>
  );
}
