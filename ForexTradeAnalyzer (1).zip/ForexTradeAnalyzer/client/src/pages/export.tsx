import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const exportSchema = z.object({
  format: z.enum(["csv", "pdf"]),
  accountId: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  includeOpenTrades: z.boolean().default(false),
  includeImages: z.boolean().default(false),
});

type ExportFormData = z.infer<typeof exportSchema>;

export default function Export() {
  const [exportHistory, setExportHistory] = useState<Array<{
    id: string;
    format: string;
    filename: string;
    date: Date;
    status: "completed" | "failed";
    downloadUrl?: string;
  }>>([]);

  const { toast } = useToast();

  const { data: accounts } = useQuery({
    queryKey: ["/api/accounts"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/trades/stats"],
  });

  const form = useForm<ExportFormData>({
    resolver: zodResolver(exportSchema),
    defaultValues: {
      format: "csv",
      includeOpenTrades: false,
      includeImages: false,
    },
  });

  const exportMutation = useMutation({
    mutationFn: async (data: ExportFormData) => {
      const params = new URLSearchParams();
      
      if (data.accountId) params.append("accountId", data.accountId);
      if (data.startDate) params.append("startDate", data.startDate);
      if (data.endDate) params.append("endDate", data.endDate);
      if (data.includeOpenTrades) params.append("includeOpen", "true");

      const url = `/api/export/${data.format}${params.toString() ? `?${params.toString()}` : ""}`;
      
      if (data.format === "csv") {
        // For CSV, directly download the file
        const response = await fetch(url);
        if (!response.ok) throw new Error("Export failed");
        
        const blob = await response.blob();
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = downloadUrl;
        a.download = `forex_trades_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(downloadUrl);
        
        return { format: "csv", filename: a.download };
      } else {
        // For PDF, we would implement PDF generation
        throw new Error("PDF export not yet implemented");
      }
    },
    onSuccess: (result) => {
      const newExport = {
        id: Date.now().toString(),
        format: result.format,
        filename: result.filename,
        date: new Date(),
        status: "completed" as const,
      };
      
      setExportHistory(prev => [newExport, ...prev]);
      
      toast({
        title: "Export Successful",
        description: `Your ${result.format.toUpperCase()} file has been downloaded successfully.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Export Failed",
        description: error instanceof Error ? error.message : "Failed to export data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ExportFormData) => {
    exportMutation.mutate(data);
  };

  const downloadTemplate = () => {
    const csvContent = `Symbol,Direction,Lot Size,Entry Price,Exit Price,Stop Loss,Take Profit,Open Time,Close Time,Pips,P&L,Comment
EURUSD,buy,0.10,1.08459,1.08789,1.08123,1.09123,2024-01-15 10:30:00,2024-01-15 12:45:00,33.0,33.00,Example completed trade
XAUUSD,sell,0.05,1945.67,1943.21,1948.50,1942.00,2024-01-15 14:15:00,2024-01-15 16:30:00,24.6,123.00,Gold scalp trade`;

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "forex_export_sample.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Bar */}
      <header className="bg-white border-b border-slate-200 p-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Export Data</h2>
          <p className="text-slate-600 mt-1">
            Export your trading data for record-keeping, analysis, or regulatory compliance
          </p>
        </div>
      </header>

      <div className="p-6 space-y-6">
        {/* Export Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Trades</p>
                  <p className="text-2xl font-bold text-slate-800 mt-1">
                    {stats?.totalTrades || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <i className="fas fa-chart-bar text-blue-600 text-xl"></i>
                </div>
              </div>
              <div className="text-sm text-slate-500 mt-2">Available for export</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Date Range</p>
                  <p className="text-lg font-bold text-slate-800 mt-1">All Time</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="fas fa-calendar text-green-600 text-xl"></i>
                </div>
              </div>
              <div className="text-sm text-slate-500 mt-2">Complete history</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Export Formats</p>
                  <p className="text-lg font-bold text-slate-800 mt-1">CSV, PDF</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <i className="fas fa-file-export text-purple-600 text-xl"></i>
                </div>
              </div>
              <div className="text-sm text-slate-500 mt-2">Multiple formats</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Export Configuration */}
          <Card>
            <CardHeader>
              <CardTitle>Export Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="format"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Export Format</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select format" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="csv">
                              <div className="flex items-center">
                                <i className="fas fa-file-csv mr-2 text-green-600"></i>
                                CSV - Spreadsheet Format
                              </div>
                            </SelectItem>
                            <SelectItem value="pdf">
                              <div className="flex items-center">
                                <i className="fas fa-file-pdf mr-2 text-red-600"></i>
                                PDF - Professional Report
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="accountId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Account (Optional)</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="All accounts" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="all">All Accounts</SelectItem>
                            {accounts?.map((account: any) => (
                              <SelectItem key={account.id} value={account.id.toString()}>
                                {account.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Start Date (Optional)</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Date (Optional)</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="includeOpenTrades"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Include Open Trades</FormLabel>
                            <p className="text-sm text-slate-600">
                              Export trades that are still open/active
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="includeImages"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              disabled={form.watch("format") === "csv"}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Include Trade Images</FormLabel>
                            <p className="text-sm text-slate-600">
                              Include chart screenshots (PDF only)
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={downloadTemplate}>
                      <i className="fas fa-download mr-2"></i>
                      Sample Format
                    </Button>
                    <Button type="submit" disabled={exportMutation.isPending}>
                      {exportMutation.isPending ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-2"></i>
                          Exporting...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-file-export mr-2"></i>
                          Export Data
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Export History */}
          <Card>
            <CardHeader>
              <CardTitle>Export History</CardTitle>
            </CardHeader>
            <CardContent>
              {exportHistory.length === 0 ? (
                <div className="text-center py-12">
                  <i className="fas fa-history text-4xl text-slate-300 mb-4"></i>
                  <p className="text-slate-600 font-medium">No exports yet</p>
                  <p className="text-sm text-slate-500 mt-1">
                    Your export history will appear here
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {exportHistory.map((exportItem) => (
                    <div
                      key={exportItem.id}
                      className="flex items-center justify-between p-4 bg-slate-50 rounded-lg"
                    >
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                          <i className={`fas ${
                            exportItem.format === "csv" ? "fa-file-csv" : "fa-file-pdf"
                          } text-blue-600`}></i>
                        </div>
                        <div>
                          <p className="font-medium text-slate-800">
                            {exportItem.filename}
                          </p>
                          <p className="text-sm text-slate-600">
                            {exportItem.date.toLocaleDateString()} at {exportItem.date.toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={exportItem.status === "completed" ? "default" : "destructive"}>
                          {exportItem.status === "completed" ? (
                            <>
                              <i className="fas fa-check mr-1"></i>
                              Complete
                            </>
                          ) : (
                            <>
                              <i className="fas fa-times mr-1"></i>
                              Failed
                            </>
                          )}
                        </Badge>
                        {exportItem.status === "completed" && (
                          <Button variant="ghost" size="sm">
                            <i className="fas fa-download"></i>
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Export Guidelines */}
        <Card>
          <CardHeader>
            <CardTitle>Export Guidelines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-slate-800 mb-3">CSV Export</h4>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-start">
                    <i className="fas fa-check text-green-600 mr-2 mt-1"></i>
                    Compatible with Excel, Google Sheets, and trading analysis software
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check text-green-600 mr-2 mt-1"></i>
                    Includes all trade data: entry/exit prices, P&L, pips, timestamps
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check text-green-600 mr-2 mt-1"></i>
                    Suitable for importing into other trading journals or tax software
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check text-green-600 mr-2 mt-1"></i>
                    Lightweight format, fast download and processing
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-slate-800 mb-3">PDF Report</h4>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-start">
                    <i className="fas fa-clock text-amber-600 mr-2 mt-1"></i>
                    Professional format for sharing with brokers or advisors
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-clock text-amber-600 mr-2 mt-1"></i>
                    Includes performance charts and statistical analysis
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-clock text-amber-600 mr-2 mt-1"></i>
                    Can include trade screenshots and AI analysis
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-clock text-amber-600 mr-2 mt-1"></i>
                    <span>Coming soon - PDF export is under development</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start">
                <i className="fas fa-info-circle text-blue-600 mr-3 mt-1"></i>
                <div>
                  <h5 className="font-medium text-blue-800">Regulatory Compliance</h5>
                  <p className="text-sm text-blue-700 mt-1">
                    Exported data maintains full audit trail including timestamps, trade IDs, and all modifications.
                    Suitable for tax reporting and regulatory compliance in most jurisdictions.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
