import CsvImport from "@/components/csv-import";

export default function ImportCsv() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Bar */}
      <header className="bg-white border-b border-slate-200 p-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Import Trades</h2>
          <p className="text-slate-600 mt-1">
            Import trades from CSV files exported by MT4/MT5, cTrader, or other platforms
          </p>
        </div>
      </header>

      <div className="p-6">
        <CsvImport />
      </div>
    </div>
  );
}
