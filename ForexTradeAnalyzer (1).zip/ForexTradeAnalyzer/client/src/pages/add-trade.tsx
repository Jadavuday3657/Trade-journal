import TradeForm from "@/components/trade-form";

export default function AddTrade() {
  return (
    <div className="bg-slate-50">
      {/* Page Header */}
      <div className="bg-white border-b border-slate-200 px-6 py-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Add New Trade</h2>
          <p className="text-slate-600 mt-1">
            Manually enter trade details or upload supporting chart images
          </p>
        </div>
      </div>

      <div className="p-6">
        <TradeForm />
      </div>
    </div>
  );
}
