import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTradeSchema, insertAccountSchema, insertCsvImportSchema } from "@shared/schema";
import { calculatePips, calculateProfitLoss, validateSymbol } from "./services/tradeCalculations";
import { parseCsvContent } from "./services/csvParser";
import { analyzeTradePerformance, analyzeTradeImage } from "./services/openai";
import multer from "multer";
import path from "path";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Account routes
  app.get("/api/accounts", async (req, res) => {
    try {
      const accounts = await storage.getAllAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch accounts" });
    }
  });

  app.post("/api/accounts", async (req, res) => {
    try {
      const validatedData = insertAccountSchema.parse(req.body);
      const account = await storage.createAccount(validatedData);
      res.status(201).json(account);
    } catch (error) {
      res.status(400).json({ message: "Invalid account data", error });
    }
  });

  // Trade routes
  app.get("/api/trades", async (req, res) => {
    try {
      const accountId = req.query.accountId ? parseInt(req.query.accountId as string) : undefined;
      const trades = await storage.getAllTrades(accountId);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trades" });
    }
  });

  app.get("/api/trades/stats", async (req, res) => {
    try {
      const accountId = req.query.accountId ? parseInt(req.query.accountId as string) : undefined;
      const stats = await storage.getTradeStats(accountId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trade statistics" });
    }
  });

  app.post("/api/trades", upload.single("image"), async (req, res) => {
    try {
      const tradeData = { ...req.body };
      
      // Handle image upload
      if (req.file) {
        const base64Image = req.file.buffer.toString('base64');
        tradeData.imageUrl = `data:${req.file.mimetype};base64,${base64Image}`;
        
        // Analyze image with AI
        try {
          const imageAnalysis = await analyzeTradeImage(base64Image);
          tradeData.imageTags = imageAnalysis.patterns;
          tradeData.aiAnalysis = JSON.stringify(imageAnalysis);
        } catch (error) {
          console.error("Image analysis failed:", error);
        }
      }

      const validatedData = insertTradeSchema.parse(tradeData);
      
      // Validate symbol
      if (!validateSymbol(validatedData.symbol)) {
        return res.status(400).json({ message: "Invalid currency symbol" });
      }

      let trade = await storage.createTrade(validatedData);

      // Calculate pips and P&L if exit price is provided
      if (trade.exitPrice) {
        const pips = calculatePips(
          trade.symbol,
          parseFloat(trade.entryPrice),
          parseFloat(trade.exitPrice),
          trade.direction as "buy" | "sell"
        );
        
        const profitLoss = calculateProfitLoss(
          trade.symbol,
          parseFloat(trade.lotSize),
          pips,
          parseFloat(trade.commission || "0"),
          parseFloat(trade.swap || "0")
        );

        trade = await storage.updateTrade(trade.id, {
          pips: pips.toString(),
          profitLoss: profitLoss.toString()
        });
      }

      res.status(201).json(trade);
    } catch (error) {
      res.status(400).json({ message: "Invalid trade data", error });
    }
  });

  app.put("/api/trades/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = { ...req.body };
      
      // Recalculate pips and P&L if relevant fields are updated
      if (updates.exitPrice || updates.entryPrice || updates.symbol || updates.direction || updates.lotSize) {
        const existingTrade = await storage.getTrade(id);
        if (!existingTrade) {
          return res.status(404).json({ message: "Trade not found" });
        }

        const entryPrice = parseFloat(updates.entryPrice || existingTrade.entryPrice);
        const exitPrice = parseFloat(updates.exitPrice || existingTrade.exitPrice || "0");
        const symbol = updates.symbol || existingTrade.symbol;
        const direction = updates.direction || existingTrade.direction;
        const lotSize = parseFloat(updates.lotSize || existingTrade.lotSize);

        if (exitPrice > 0) {
          const pips = calculatePips(symbol, entryPrice, exitPrice, direction as "buy" | "sell");
          const profitLoss = calculateProfitLoss(
            symbol,
            lotSize,
            pips,
            parseFloat(updates.commission || existingTrade.commission || "0"),
            parseFloat(updates.swap || existingTrade.swap || "0")
          );

          updates.pips = pips.toString();
          updates.profitLoss = profitLoss.toString();
        }
      }

      const trade = await storage.updateTrade(id, updates);
      res.json(trade);
    } catch (error) {
      res.status(400).json({ message: "Failed to update trade", error });
    }
  });

  app.delete("/api/trades/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTrade(id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ message: "Failed to delete trade", error });
    }
  });

  // CSV Import routes
  app.post("/api/csv-import", upload.single("csvFile"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No CSV file provided" });
      }

      const csvContent = req.file.buffer.toString('utf-8');
      const parseResult = parseCsvContent(csvContent);

      const csvImport = await storage.createCsvImport({
        filename: req.file.originalname,
        accountId: req.body.accountId ? parseInt(req.body.accountId) : null,
        status: "processing",
        totalRows: parseResult.trades.length,
        successRows: 0,
        errorRows: parseResult.errors.length,
        errors: parseResult.errors,
      });

      // Process trades
      let successCount = 0;
      const errors: string[] = [...parseResult.errors];

      for (const [index, tradeData] of parseResult.trades.entries()) {
        try {
          const insertData = {
            ...tradeData,
            accountId: req.body.accountId ? parseInt(req.body.accountId) : null,
            lotSize: tradeData.lotSize.toString(),
            entryPrice: tradeData.entryPrice.toString(),
            exitPrice: tradeData.exitPrice?.toString(),
            stopLoss: tradeData.stopLoss?.toString(),
            takeProfit: tradeData.takeProfit?.toString(),
          };

          let trade = await storage.createTrade(insertData);

          // Calculate pips and P&L if exit price is provided
          if (trade.exitPrice) {
            const pips = calculatePips(
              trade.symbol,
              parseFloat(trade.entryPrice),
              parseFloat(trade.exitPrice),
              trade.direction as "buy" | "sell"
            );
            
            const profitLoss = calculateProfitLoss(
              trade.symbol,
              parseFloat(trade.lotSize),
              pips
            );

            await storage.updateTrade(trade.id, {
              pips: pips.toString(),
              profitLoss: profitLoss.toString()
            });
          }

          successCount++;
        } catch (error) {
          errors.push(`Trade ${index + 1}: ${error instanceof Error ? error.message : 'Processing error'}`);
        }
      }

      await storage.updateCsvImport(csvImport.id, {
        status: "completed",
        successRows: successCount,
        errorRows: errors.length - parseResult.errors.length,
        errors,
      });

      res.json({
        importId: csvImport.id,
        detectedFormat: parseResult.detectedFormat,
        totalRows: parseResult.trades.length,
        successRows: successCount,
        errorRows: errors.length - parseResult.errors.length,
        errors,
      });
    } catch (error) {
      res.status(500).json({ message: "CSV import failed", error });
    }
  });

  app.get("/api/csv-imports", async (req, res) => {
    try {
      const imports = await storage.getAllCsvImports();
      res.json(imports);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch imports" });
    }
  });

  // AI Insights route
  app.get("/api/ai-insights", async (req, res) => {
    try {
      const accountId = req.query.accountId ? parseInt(req.query.accountId as string) : undefined;
      const trades = await storage.getAllTrades(accountId);
      const closedTrades = trades.filter(trade => trade.exitPrice && trade.profitLoss);
      
      const insights = await analyzeTradePerformance(closedTrades);
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate AI insights", error });
    }
  });

  // Export routes
  app.get("/api/export/csv", async (req, res) => {
    try {
      const accountId = req.query.accountId ? parseInt(req.query.accountId as string) : undefined;
      const trades = await storage.getAllTrades(accountId);
      
      const csvHeaders = [
        "ID", "Symbol", "Direction", "Lot Size", "Entry Price", "Exit Price", 
        "Stop Loss", "Take Profit", "Open Time", "Close Time", "Pips", "P&L", "Comment"
      ];
      
      const csvRows = trades.map(trade => [
        trade.id,
        trade.symbol,
        trade.direction,
        trade.lotSize,
        trade.entryPrice,
        trade.exitPrice || "",
        trade.stopLoss || "",
        trade.takeProfit || "",
        trade.openTime,
        trade.closeTime || "",
        trade.pips || "",
        trade.profitLoss || "",
        trade.comment || ""
      ]);

      const csvContent = [csvHeaders, ...csvRows]
        .map(row => row.map(cell => `"${cell}"`).join(","))
        .join("\n");

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=trades.csv");
      res.send(csvContent);
    } catch (error) {
      res.status(500).json({ message: "Export failed", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
