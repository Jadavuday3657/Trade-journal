interface CsvRow {
  [key: string]: string;
}

interface ParsedTrade {
  symbol: string;
  direction: "buy" | "sell";
  lotSize: number;
  entryPrice: number;
  exitPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  openTime: Date;
  closeTime?: Date;
  tradeId?: string;
  comment?: string;
}

interface CsvParseResult {
  trades: ParsedTrade[];
  errors: string[];
  detectedFormat: "mt4" | "mt5" | "ctrader" | "custom" | "unknown";
}

export function detectCsvFormat(headers: string[]): "mt4" | "mt5" | "ctrader" | "custom" | "unknown" {
  const headerStr = headers.join(",").toLowerCase();
  
  if (headerStr.includes("ticket") && headerStr.includes("open time") && headerStr.includes("type")) {
    return "mt4";
  }
  if (headerStr.includes("position id") && headerStr.includes("open timestamp")) {
    return "ctrader";
  }
  if (headerStr.includes("ticket") && headerStr.includes("time")) {
    return "mt5";
  }
  if (headerStr.includes("symbol") && headerStr.includes("direction")) {
    return "custom";
  }
  
  return "unknown";
}

export function parseCsvContent(csvContent: string): CsvParseResult {
  const lines = csvContent.split('\n').filter(line => line.trim());
  if (lines.length < 2) {
    return {
      trades: [],
      errors: ["CSV file must contain at least a header row and one data row"],
      detectedFormat: "unknown"
    };
  }

  const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
  const detectedFormat = detectCsvFormat(headers);
  const trades: ParsedTrade[] = [];
  const errors: string[] = [];

  for (let i = 1; i < lines.length; i++) {
    try {
      const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
      const row: CsvRow = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });

      const parsedTrade = parseRowToTrade(row, detectedFormat);
      if (parsedTrade) {
        trades.push(parsedTrade);
      }
    } catch (error) {
      errors.push(`Row ${i + 1}: ${error instanceof Error ? error.message : 'Parse error'}`);
    }
  }

  return {
    trades,
    errors,
    detectedFormat
  };
}

function parseRowToTrade(row: CsvRow, format: string): ParsedTrade | null {
  try {
    let symbol: string;
    let direction: "buy" | "sell";
    let lotSize: number;
    let entryPrice: number;
    let exitPrice: number | undefined;
    let openTime: Date;
    let closeTime: Date | undefined;
    let tradeId: string | undefined;

    switch (format) {
      case "mt4":
      case "mt5":
        symbol = row["Symbol"] || row["symbol"] || "";
        const type = row["Type"] || row["type"] || "";
        direction = type.toLowerCase().includes("buy") ? "buy" : "sell";
        lotSize = parseFloat(row["Volume"] || row["volume"] || row["Lots"] || "0");
        entryPrice = parseFloat(row["Price"] || row["price"] || row["Open Price"] || "0");
        exitPrice = parseFloat(row["Close Price"] || row["close price"] || "0") || undefined;
        openTime = new Date(row["Open Time"] || row["open time"] || row["Time"] || "");
        closeTime = row["Close Time"] || row["close time"] ? new Date(row["Close Time"] || row["close time"] || "") : undefined;
        tradeId = row["Ticket"] || row["ticket"] || row["Order"] || row["order"];
        break;

      case "ctrader":
        symbol = row["Symbol"] || "";
        direction = (row["Side"] || "").toLowerCase() === "buy" ? "buy" : "sell";
        lotSize = parseFloat(row["Volume"] || "0") / 100000; // cTrader uses units
        entryPrice = parseFloat(row["Entry Price"] || "0");
        exitPrice = parseFloat(row["Close Price"] || "0") || undefined;
        openTime = new Date(row["Open Timestamp"] || "");
        closeTime = row["Close Timestamp"] ? new Date(row["Close Timestamp"]) : undefined;
        tradeId = row["Position ID"];
        break;

      case "custom":
        symbol = row["symbol"] || row["Symbol"] || "";
        direction = (row["direction"] || row["Direction"] || "").toLowerCase() as "buy" | "sell";
        lotSize = parseFloat(row["lotSize"] || row["lot_size"] || row["Lot Size"] || "0");
        entryPrice = parseFloat(row["entryPrice"] || row["entry_price"] || row["Entry Price"] || "0");
        exitPrice = parseFloat(row["exitPrice"] || row["exit_price"] || row["Exit Price"] || "0") || undefined;
        openTime = new Date(row["openTime"] || row["open_time"] || row["Open Time"] || "");
        closeTime = row["closeTime"] || row["close_time"] || row["Close Time"] ? new Date(row["closeTime"] || row["close_time"] || row["Close Time"] || "") : undefined;
        tradeId = row["tradeId"] || row["trade_id"] || row["Trade ID"];
        break;

      default:
        return null;
    }

    // Validation
    if (!symbol || !direction || !lotSize || !entryPrice || !openTime || isNaN(openTime.getTime())) {
      throw new Error("Missing required fields: symbol, direction, lotSize, entryPrice, openTime");
    }

    if (!["buy", "sell"].includes(direction)) {
      throw new Error("Direction must be 'buy' or 'sell'");
    }

    return {
      symbol: symbol.toUpperCase(),
      direction,
      lotSize,
      entryPrice,
      exitPrice: exitPrice && exitPrice > 0 ? exitPrice : undefined,
      openTime,
      closeTime: closeTime && !isNaN(closeTime.getTime()) ? closeTime : undefined,
      tradeId,
      comment: row["Comment"] || row["comment"] || ""
    };
  } catch (error) {
    throw new Error(`Failed to parse trade: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
