export function calculatePips(symbol: string, entryPrice: number, exitPrice: number, direction: "buy" | "sell"): number {
  let pipValue: number;
  let priceDiff = exitPrice - entryPrice;
  
  // Adjust for direction
  if (direction === "sell") {
    priceDiff = -priceDiff;
  }

  // Determine pip value based on symbol
  if (symbol.includes("JPY")) {
    // JPY pairs have different pip calculation
    pipValue = priceDiff * 100;
  } else if (symbol === "XAUUSD") {
    // Gold uses 0.1 pip precision
    pipValue = priceDiff * 10;
  } else {
    // Standard forex pairs
    pipValue = priceDiff * 10000;
  }

  return Math.round(pipValue * 100) / 100; // Round to 2 decimal places
}

export function calculateProfitLoss(
  symbol: string,
  lotSize: number,
  pips: number,
  commission: number = 0,
  swap: number = 0
): number {
  let pipValuePerLot: number;

  // Determine pip value per lot based on symbol
  if (symbol.includes("JPY")) {
    pipValuePerLot = 1000; // $10 per pip for 1 lot on JPY pairs
  } else if (symbol === "XAUUSD") {
    pipValuePerLot = 1000; // $10 per pip for 1 lot on XAUUSD
  } else {
    pipValuePerLot = 1000; // $10 per pip for 1 lot on standard pairs
  }

  const grossPnL = (pips * pipValuePerLot * lotSize) / 100;
  const netPnL = grossPnL - commission - swap;

  return Math.round(netPnL * 100) / 100; // Round to 2 decimal places
}

export function calculateTradeDuration(openTime: Date, closeTime: Date): string {
  const diffMs = closeTime.getTime() - openTime.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

  if (diffHours > 24) {
    const days = Math.floor(diffHours / 24);
    const hours = diffHours % 24;
    return `${days}d ${hours}h`;
  } else if (diffHours > 0) {
    return `${diffHours}h ${diffMinutes}m`;
  } else {
    return `${diffMinutes}m`;
  }
}

export function validateSymbol(symbol: string): boolean {
  const validSymbols = [
    "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD",
    "EURJPY", "GBPJPY", "AUDJPY", "CHFJPY", "CADJPY", "NZDJPY",
    "EURGBP", "EURAUD", "EURCHF", "EURCAD", "EURNZD",
    "GBPAUD", "GBPCHF", "GBPCAD", "GBPNZD",
    "AUDCHF", "AUDCAD", "AUDNZD",
    "CADCHF", "NZDCHF", "NZDCAD",
    "XAUUSD", "XAGUSD"
  ];
  return validSymbols.includes(symbol.toUpperCase());
}
