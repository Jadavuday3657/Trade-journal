import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" });

export async function analyzeTradePerformance(trades: any[]): Promise<{
  insights: string[];
  recommendations: string[];
  warnings: string[];
  weeklyGoals: {
    winRateTarget: number;
    pnlTarget: number;
    maxDrawdown: number;
  };
}> {
  try {
    const prompt = `Analyze the following forex trading data and provide professional insights:

${JSON.stringify(trades, null, 2)}

Please provide:
1. Key performance insights (3-5 bullet points)
2. Actionable recommendations for improvement (3-5 bullet points)  
3. Risk management warnings if any (1-3 bullet points)
4. Weekly performance goals (win rate target %, P&L target $, max drawdown %)

Respond with JSON in this format:
{
  "insights": ["insight1", "insight2", ...],
  "recommendations": ["rec1", "rec2", ...], 
  "warnings": ["warning1", "warning2", ...],
  "weeklyGoals": {
    "winRateTarget": 70,
    "pnlTarget": 500,
    "maxDrawdown": 2
  }
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a professional forex trading analyst. Analyze trading performance data and provide actionable insights for traders."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    return {
      insights: ["Unable to generate AI insights at this time"],
      recommendations: ["Please check your API configuration"],
      warnings: [],
      weeklyGoals: {
        winRateTarget: 70,
        pnlTarget: 500,
        maxDrawdown: 2
      }
    };
  }
}

export async function analyzeTradeImage(base64Image: string): Promise<{
  patterns: string[];
  keyLevels: string[];
  confidence: number;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this forex trading chart image. Identify chart patterns, key support/resistance levels, and provide a confidence score (0-100). Respond with JSON in this format: {\"patterns\": [\"pattern1\", \"pattern2\"], \"keyLevels\": [\"Support: 1.2345\", \"Resistance: 1.2567\"], \"confidence\": 85}"
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 500,
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Image analysis error:", error);
    return {
      patterns: [],
      keyLevels: [],
      confidence: 0
    };
  }
}
