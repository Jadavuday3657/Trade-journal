import { accounts, trades, csvImports, type Account, type InsertAccount, type Trade, type InsertTrade, type CsvImport, type InsertCsvImport } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Accounts
  getAccount(id: number): Promise<Account | undefined>;
  getAllAccounts(): Promise<Account[]>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: number, account: Partial<InsertAccount>): Promise<Account>;

  // Trades
  getTrade(id: number): Promise<Trade | undefined>;
  getAllTrades(accountId?: number): Promise<Trade[]>;
  getTradesByDateRange(startDate: Date, endDate: Date, accountId?: number): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: number, trade: Partial<InsertTrade>): Promise<Trade>;
  deleteTrade(id: number): Promise<void>;
  getTradeStats(accountId?: number): Promise<{
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    totalPnL: number;
    winRate: number;
    profitFactor: number;
    maxDrawdown: number;
  }>;

  // CSV Imports
  getCsvImport(id: number): Promise<CsvImport | undefined>;
  getAllCsvImports(): Promise<CsvImport[]>;
  createCsvImport(csvImport: InsertCsvImport): Promise<CsvImport>;
  updateCsvImport(id: number, csvImport: Partial<InsertCsvImport>): Promise<CsvImport>;
}

export class MemStorage implements IStorage {
  private accounts: Map<number, Account>;
  private trades: Map<number, Trade>;
  private csvImports: Map<number, CsvImport>;
  private currentAccountId: number;
  private currentTradeId: number;
  private currentCsvImportId: number;

  constructor() {
    this.accounts = new Map();
    this.trades = new Map();
    this.csvImports = new Map();
    this.currentAccountId = 1;
    this.currentTradeId = 1;
    this.currentCsvImportId = 1;

    // Create default accounts
    this.createAccount({
      name: "MT5-Demo-12345 (Demo)",
      type: "demo",
      accountNumber: "12345",
      balance: "10000.00",
      isActive: true,
    });
    this.createAccount({
      name: "MT5-Live-67890 (Live)",
      type: "live",
      accountNumber: "67890",
      balance: "5000.00",
      isActive: true,
    });
    this.createAccount({
      name: "Manual Entry",
      type: "manual",
      accountNumber: null,
      balance: "0.00",
      isActive: true,
    });
  }

  async getAccount(id: number): Promise<Account | undefined> {
    return this.accounts.get(id);
  }

  async getAllAccounts(): Promise<Account[]> {
    return Array.from(this.accounts.values());
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const id = this.currentAccountId++;
    const account: Account = { ...insertAccount, id };
    this.accounts.set(id, account);
    return account;
  }

  async updateAccount(id: number, updateAccount: Partial<InsertAccount>): Promise<Account> {
    const existing = this.accounts.get(id);
    if (!existing) {
      throw new Error(`Account with id ${id} not found`);
    }
    const updated: Account = { ...existing, ...updateAccount };
    this.accounts.set(id, updated);
    return updated;
  }

  async getTrade(id: number): Promise<Trade | undefined> {
    return this.trades.get(id);
  }

  async getAllTrades(accountId?: number): Promise<Trade[]> {
    const allTrades = Array.from(this.trades.values());
    if (accountId) {
      return allTrades.filter(trade => trade.accountId === accountId);
    }
    return allTrades;
  }

  async getTradesByDateRange(startDate: Date, endDate: Date, accountId?: number): Promise<Trade[]> {
    const allTrades = await this.getAllTrades(accountId);
    return allTrades.filter(trade => {
      const openTime = new Date(trade.openTime);
      return openTime >= startDate && openTime <= endDate;
    });
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = this.currentTradeId++;
    const trade: Trade = { 
      ...insertTrade, 
      id,
      pips: null,
      profitLoss: null,
      imageTags: insertTrade.imageTags || [],
      tags: insertTrade.tags || [],
    };
    this.trades.set(id, trade);
    return trade;
  }

  async updateTrade(id: number, updateTrade: Partial<InsertTrade>): Promise<Trade> {
    const existing = this.trades.get(id);
    if (!existing) {
      throw new Error(`Trade with id ${id} not found`);
    }
    const updated: Trade = { ...existing, ...updateTrade };
    this.trades.set(id, updated);
    return updated;
  }

  async deleteTrade(id: number): Promise<void> {
    this.trades.delete(id);
  }

  async getTradeStats(accountId?: number): Promise<{
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    totalPnL: number;
    winRate: number;
    profitFactor: number;
    maxDrawdown: number;
  }> {
    const trades = await this.getAllTrades(accountId);
    const closedTrades = trades.filter(trade => trade.exitPrice && trade.profitLoss);
    
    const totalTrades = closedTrades.length;
    const winningTrades = closedTrades.filter(trade => parseFloat(trade.profitLoss || "0") > 0).length;
    const losingTrades = closedTrades.filter(trade => parseFloat(trade.profitLoss || "0") < 0).length;
    const totalPnL = closedTrades.reduce((sum, trade) => sum + parseFloat(trade.profitLoss || "0"), 0);
    const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
    
    const grossProfit = closedTrades
      .filter(trade => parseFloat(trade.profitLoss || "0") > 0)
      .reduce((sum, trade) => sum + parseFloat(trade.profitLoss || "0"), 0);
    const grossLoss = Math.abs(closedTrades
      .filter(trade => parseFloat(trade.profitLoss || "0") < 0)
      .reduce((sum, trade) => sum + parseFloat(trade.profitLoss || "0"), 0));
    
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? grossProfit : 0;
    
    // Calculate max drawdown
    let maxDrawdown = 0;
    let peak = 0;
    let runningPnL = 0;
    
    for (const trade of closedTrades.sort((a, b) => new Date(a.openTime).getTime() - new Date(b.openTime).getTime())) {
      runningPnL += parseFloat(trade.profitLoss || "0");
      if (runningPnL > peak) {
        peak = runningPnL;
      }
      const drawdown = ((peak - runningPnL) / (peak || 1)) * 100;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }
    }

    return {
      totalTrades,
      winningTrades,
      losingTrades,
      totalPnL,
      winRate,
      profitFactor,
      maxDrawdown,
    };
  }

  async getCsvImport(id: number): Promise<CsvImport | undefined> {
    return this.csvImports.get(id);
  }

  async getAllCsvImports(): Promise<CsvImport[]> {
    return Array.from(this.csvImports.values());
  }

  async createCsvImport(insertCsvImport: InsertCsvImport): Promise<CsvImport> {
    const id = this.currentCsvImportId++;
    const csvImport: CsvImport = { 
      ...insertCsvImport, 
      id,
      importTime: new Date(),
      errors: insertCsvImport.errors || [],
    };
    this.csvImports.set(id, csvImport);
    return csvImport;
  }

  async updateCsvImport(id: number, updateCsvImport: Partial<InsertCsvImport>): Promise<CsvImport> {
    const existing = this.csvImports.get(id);
    if (!existing) {
      throw new Error(`CSV import with id ${id} not found`);
    }
    const updated: CsvImport = { ...existing, ...updateCsvImport };
    this.csvImports.set(id, updated);
    return updated;
  }
}

// rewrite MemStorage to DatabaseStorage
export class DatabaseStorage implements IStorage {
  async getAccount(id: number): Promise<Account | undefined> {
    const [account] = await db.select().from(accounts).where(eq(accounts.id, id));
    return account || undefined;
  }

  async getAllAccounts(): Promise<Account[]> {
    return await db.select().from(accounts);
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const [account] = await db
      .insert(accounts)
      .values(insertAccount)
      .returning();
    return account;
  }

  async updateAccount(id: number, updateAccount: Partial<InsertAccount>): Promise<Account> {
    const [account] = await db
      .update(accounts)
      .set(updateAccount)
      .where(eq(accounts.id, id))
      .returning();
    return account;
  }

  async getTrade(id: number): Promise<Trade | undefined> {
    const [trade] = await db.select().from(trades).where(eq(trades.id, id));
    return trade || undefined;
  }

  async getAllTrades(accountId?: number): Promise<Trade[]> {
    if (accountId) {
      return await db.select().from(trades).where(eq(trades.accountId, accountId));
    }
    return await db.select().from(trades);
  }

  async getTradesByDateRange(startDate: Date, endDate: Date, accountId?: number): Promise<Trade[]> {
    let query = db.select().from(trades);
    
    if (accountId) {
      query = query.where(eq(trades.accountId, accountId));
    }
    
    return await query;
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const [trade] = await db
      .insert(trades)
      .values(insertTrade)
      .returning();
    return trade;
  }

  async updateTrade(id: number, updateTrade: Partial<InsertTrade>): Promise<Trade> {
    const [trade] = await db
      .update(trades)
      .set(updateTrade)
      .where(eq(trades.id, id))
      .returning();
    return trade;
  }

  async deleteTrade(id: number): Promise<void> {
    await db.delete(trades).where(eq(trades.id, id));
  }

  async getTradeStats(accountId?: number): Promise<{
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    totalPnL: number;
    winRate: number;
    profitFactor: number;
    maxDrawdown: number;
  }> {
    const allTrades = await this.getAllTrades(accountId);
    
    const totalTrades = allTrades.length;
    const winningTrades = allTrades.filter(t => t.profitLoss && parseFloat(t.profitLoss) > 0).length;
    const losingTrades = allTrades.filter(t => t.profitLoss && parseFloat(t.profitLoss) < 0).length;
    const totalPnL = allTrades.reduce((sum, t) => sum + (t.profitLoss ? parseFloat(t.profitLoss) : 0), 0);
    const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
    
    const profits = allTrades.filter(t => t.profitLoss && parseFloat(t.profitLoss) > 0).reduce((sum, t) => sum + parseFloat(t.profitLoss!), 0);
    const losses = Math.abs(allTrades.filter(t => t.profitLoss && parseFloat(t.profitLoss) < 0).reduce((sum, t) => sum + parseFloat(t.profitLoss!), 0));
    const profitFactor = losses > 0 ? profits / losses : profits > 0 ? 999 : 0;
    
    const maxDrawdown = 0; // Simplified for now
    
    return {
      totalTrades,
      winningTrades,
      losingTrades,
      totalPnL,
      winRate,
      profitFactor,
      maxDrawdown,
    };
  }

  async getCsvImport(id: number): Promise<CsvImport | undefined> {
    const [csvImport] = await db.select().from(csvImports).where(eq(csvImports.id, id));
    return csvImport || undefined;
  }

  async getAllCsvImports(): Promise<CsvImport[]> {
    return await db.select().from(csvImports);
  }

  async createCsvImport(insertCsvImport: InsertCsvImport): Promise<CsvImport> {
    const [csvImport] = await db
      .insert(csvImports)
      .values(insertCsvImport)
      .returning();
    return csvImport;
  }

  async updateCsvImport(id: number, updateCsvImport: Partial<InsertCsvImport>): Promise<CsvImport> {
    const [csvImport] = await db
      .update(csvImports)
      .set(updateCsvImport)
      .where(eq(csvImports.id, id))
      .returning();
    return csvImport;
  }
}

export const storage = new DatabaseStorage();
