# ForexAI Journal

## Overview

ForexAI Journal is a professional forex trading analytics application that combines trade management, AI-powered analysis, and comprehensive performance tracking. The system allows traders to manually log trades, import data from various trading platforms, and receive AI-driven insights to improve their trading performance.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Build Tool**: Vite with hot module replacement for development

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API endpoints
- **File Processing**: Multer for file uploads and CSV processing
- **Development**: tsx for TypeScript execution in development

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Drizzle Kit for migrations
- **Development Storage**: In-memory storage implementation for quick development

## Key Components

### Database Schema
The application uses three main tables:
- **Accounts**: Trading account management (demo, live, manual types)
- **Trades**: Core trade data with comprehensive fields for forex trading
- **CSV Imports**: Track import operations and their status

### Trading Features
- **Manual Trade Entry**: Full trade lifecycle management with image uploads
- **CSV Import**: Support for MT4/MT5, cTrader, and custom formats
- **Performance Analytics**: Win rate, P&L, drawdown calculations
- **Currency Pair Support**: Major, minor, and exotic forex pairs plus gold/silver

### AI Integration
- **OpenAI Integration**: GPT-4o model for trade analysis
- **Performance Insights**: Automated analysis of trading patterns
- **Image Analysis**: Chart analysis capabilities for uploaded trade screenshots
- **Recommendations**: AI-generated trading improvement suggestions

### User Interface
- **Dashboard**: Overview with stats cards, equity curve, and recent trades
- **Trade Management**: Add trades manually or via CSV import
- **History View**: Comprehensive trade history with filtering
- **AI Insights**: Performance analysis and recommendations
- **Export Functionality**: Data export in various formats

## Data Flow

1. **Trade Input**: Users can manually enter trades or import CSV files
2. **Data Processing**: Trade calculations (pips, P&L) are performed server-side
3. **Storage**: Data is persisted using Drizzle ORM
4. **Analytics**: Performance metrics are calculated on-demand
5. **AI Analysis**: OpenAI integration provides insights and recommendations
6. **Visualization**: React components render charts and tables for data visualization

## External Dependencies

### Core Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: drizzle-orm and drizzle-kit for database operations
- **AI**: OpenAI SDK for trade analysis
- **File Processing**: multer for CSV uploads
- **UI Components**: Extensive Radix UI component library
- **Validation**: Zod for schema validation and type safety

### Development Tools
- **Build**: Vite for fast development and optimized builds
- **TypeScript**: Full type safety across frontend and backend
- **CSS**: Tailwind CSS with PostCSS processing
- **Development**: Replit-specific plugins for enhanced development experience

## Deployment Strategy

### Production Build
- **Frontend**: Vite builds static assets to dist/public
- **Backend**: esbuild bundles server code to dist/index.js
- **Database**: Drizzle migrations handle schema updates

### Environment Configuration
- **Development**: Uses tsx for TypeScript execution with HMR
- **Production**: Node.js serves bundled JavaScript
- **Database**: Environment variable configuration for database URL
- **AI**: OpenAI API key configuration

### Scaling Considerations
- **Database**: Designed for PostgreSQL with connection pooling
- **File Storage**: Currently uses memory storage, can be extended to cloud storage
- **AI Processing**: Rate-limited OpenAI API calls with error handling

## Changelog
- June 26, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.